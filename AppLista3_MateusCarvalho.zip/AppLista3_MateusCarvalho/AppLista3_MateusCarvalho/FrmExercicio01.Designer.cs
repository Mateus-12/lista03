﻿namespace AppLista3_MateusCarvalho
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnmedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblSoma = new System.Windows.Forms.Label();
            this.lblMedia = new System.Windows.Forms.Label();
            this.lblPorcentagem = new System.Windows.Forms.Label();
            this.lblPorcentagemN2 = new System.Windows.Forms.Label();
            this.lblPorcentagemN3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(27, 28);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(142, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Exercício 01";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(55, 100);
            this.txtN1.Multiline = true;
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(156, 38);
            this.txtN1.TabIndex = 1;
            this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(318, 100);
            this.txtN2.Multiline = true;
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(156, 38);
            this.txtN2.TabIndex = 2;
            // 
            // txtN3
            // 
            this.txtN3.Location = new System.Drawing.Point(574, 100);
            this.txtN3.Multiline = true;
            this.txtN3.Name = "txtN3";
            this.txtN3.Size = new System.Drawing.Size(156, 38);
            this.txtN3.TabIndex = 3;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(55, 203);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(156, 44);
            this.btnSoma.TabIndex = 4;
            this.btnSoma.Text = "A) Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnmedia
            // 
            this.btnmedia.Location = new System.Drawing.Point(318, 203);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(156, 44);
            this.btnmedia.TabIndex = 5;
            this.btnmedia.Text = "B) Média";
            this.btnmedia.UseVisualStyleBackColor = true;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(574, 203);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(156, 44);
            this.btnPorcentagem.TabIndex = 6;
            this.btnPorcentagem.Text = "C) Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // lblSoma
            // 
            this.lblSoma.AutoSize = true;
            this.lblSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoma.Location = new System.Drawing.Point(181, 293);
            this.lblSoma.Name = "lblSoma";
            this.lblSoma.Size = new System.Drawing.Size(14, 20);
            this.lblSoma.TabIndex = 7;
            this.lblSoma.Text = "-";
            // 
            // lblMedia
            // 
            this.lblMedia.AutoSize = true;
            this.lblMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedia.Location = new System.Drawing.Point(181, 313);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(14, 20);
            this.lblMedia.TabIndex = 8;
            this.lblMedia.Text = "-";
            // 
            // lblPorcentagem
            // 
            this.lblPorcentagem.AutoSize = true;
            this.lblPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorcentagem.Location = new System.Drawing.Point(181, 333);
            this.lblPorcentagem.Name = "lblPorcentagem";
            this.lblPorcentagem.Size = new System.Drawing.Size(14, 20);
            this.lblPorcentagem.TabIndex = 9;
            this.lblPorcentagem.Text = "-";
            // 
            // lblPorcentagemN2
            // 
            this.lblPorcentagemN2.AutoSize = true;
            this.lblPorcentagemN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorcentagemN2.Location = new System.Drawing.Point(181, 353);
            this.lblPorcentagemN2.Name = "lblPorcentagemN2";
            this.lblPorcentagemN2.Size = new System.Drawing.Size(14, 20);
            this.lblPorcentagemN2.TabIndex = 10;
            this.lblPorcentagemN2.Text = "-";
            // 
            // lblPorcentagemN3
            // 
            this.lblPorcentagemN3.AutoSize = true;
            this.lblPorcentagemN3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorcentagemN3.Location = new System.Drawing.Point(181, 373);
            this.lblPorcentagemN3.Name = "lblPorcentagemN3";
            this.lblPorcentagemN3.Size = new System.Drawing.Size(14, 20);
            this.lblPorcentagemN3.TabIndex = 11;
            this.lblPorcentagemN3.Text = "-";
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 486);
            this.Controls.Add(this.lblPorcentagemN3);
            this.Controls.Add(this.lblPorcentagemN2);
            this.Controls.Add(this.lblPorcentagem);
            this.Controls.Add(this.lblMedia);
            this.Controls.Add(this.lblSoma);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnmedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtN3);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FrmExercicio01";
            this.Text = "Exercicío 01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.TextBox txtN3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblSoma;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.Label lblPorcentagem;
        private System.Windows.Forms.Label lblPorcentagemN2;
        private System.Windows.Forms.Label lblPorcentagemN3;
    }
}

