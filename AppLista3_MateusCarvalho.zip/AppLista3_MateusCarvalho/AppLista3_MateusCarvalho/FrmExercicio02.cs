﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_MateusCarvalho
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float vlrTotal = float.Parse(txtTotal.Text);
            float vlrLitro = float.Parse(txtLitro.Text);
            float totalEmLitros;
                totalEmLitros = vlrTotal / vlrLitro;
            lblResultado.Text = "O quantidade de Litros é: " + totalEmLitros;
        }

        private void lblTítulo_Click(object sender, EventArgs e)
        {

        }
    }
}
