﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_MateusCarvalho
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float N2 = float.Parse(txtN2.Text);
            float N3 = float.Parse(txtN3.Text);
            float soma = N1 + N3;
            lblSoma.Text = "A soma dos números e igual a: " + soma;
            
        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float N2 = float.Parse(txtN2.Text);
            float N3 = float.Parse(txtN3.Text);
            float Media = (N1 + N2 + N3)/3;
            lblMedia.Text = "A média dos três números é igual a: " + Media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float N2 = float.Parse(txtN2.Text);
            float N3 = float.Parse(txtN3.Text);
            float Porcentagem = (N1/100)*100;
            float porcentagemN2 = (N2/100)*100;
            float porcentaGEMn3 = (N3 / 100)*100;
            lblPorcentagem.Text = "A porcentagem do primeiro número é: " + Porcentagem;
            lblPorcentagemN2.Text = "A porcentagem do segundo número é: " + porcentagemN2;
            lblPorcentagemN3.Text = "A porcentagem do terceiro Número é: " + porcentaGEMn3;
        }
    }
}
