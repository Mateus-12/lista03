﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_MateusCarvalho
{
    public partial class FrmExercicio6 : Form
    {
        public FrmExercicio6()
        {
            InitializeComponent();
        }

        private void btnCubo_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float resultado = (N1 * N1) * N1;
            lblResultado.Text = "O cubo do Número digitado é: " + resultado;
        }
    }
}
