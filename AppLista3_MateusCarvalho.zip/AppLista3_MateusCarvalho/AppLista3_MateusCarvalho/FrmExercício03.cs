﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_MateusCarvalho
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtPeso.Text);
            float resultado = (N1 / 1000) * 34;
            lblPreco.Text = "O valor do Prato é de " + resultado+" Reais";

        }
    }
}
