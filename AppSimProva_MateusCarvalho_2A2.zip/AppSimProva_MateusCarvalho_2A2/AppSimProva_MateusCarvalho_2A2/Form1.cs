﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MateusCarvalho_2A2
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void FrmExercicio01_Load(object sender, EventArgs e)
        {

        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float resultado = N1-(N1 * 0.12f);
            lblResultado.Text = "O Valor com desconto é: " + resultado;
        }
    }
}
