﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MateusCarvalho_2A2
{
    public partial class Frmexercicio05 : Form
    {
        public Frmexercicio05()
        {
            InitializeComponent();
        }
    }
}
