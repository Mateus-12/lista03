﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MateusCarvalho_2A2
{
    public partial class Frmexercicio02 : Form
    {
        public Frmexercicio02()
        {
            InitializeComponent();
        }

        private void btnParcela_Click(object sender, EventArgs e)
        {
            float valor = float.Parse(txtCompra.Text);
            float valorintegral = valor*0.4f ;
            float parcelas = (valor - valorintegral) / 3;
            lblParcela.Text = "o valor de cada uma das tres parcelas é:" + parcelas;

        }

        private void btnValorPagar_Click(object sender, EventArgs e)
        {
            float valor = float.Parse(txtCompra.Text);
            float valorintegral = valor * 0.4f;
            lblValorPagar.Text = "O valor a pagar é; " + valorintegral;
        }
    }
}
